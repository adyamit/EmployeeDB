from django.contrib import admin
from polls.models import Employee
# Register your models here.
class EmployeeAdmin(admin.ModelAdmin):
    list_display=['ename','email','phonenumber','designation','companyname']



admin.site.register(Employee,EmployeeAdmin)