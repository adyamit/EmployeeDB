from django.shortcuts import render
from polls.models import Employee
from django.views.generic import ListView,DetailView
# Create your views here.
class EmployeeListView(ListView):
    model=Employee

class EmployeeDetailView(DetailView):
    model=Employee