from django.db import models

# Create your models here.
class Employee(models.Model):
    ename=models.CharField(max_length=64)
    email=models.EmailField()
    phonenumber=models.IntegerField()
    designation=models.CharField(max_length=64)
    companyname=models.CharField(max_length=64)